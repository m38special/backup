# STATE.md — Current Task State

_Last updated: 2026-02-28_

---

## Active Position

- **Primary:** SENTINEL token detection live
- **Secondary:** UAI Phase 2 deployment
- **Tertiary:** Agent onboarding

---

## Wave Execution

### Wave 1 (Parallel)
- [x] SENTINEL MVP deployed
- [x] AXIOM listener deployed
- [x] CIPHER listener ready (not deployed)
- [x] NOVA scraper ready

### Wave 2 (Sequential)
- [x] Celery tasks built: score_token, risk_filter, alert_router, store_token, nova_scan
- [ ] Verify token flow end-to-end

### Wave 3 (Awaiting)
- [ ] Wire sentinel.py → score_and_route.delay()
- [ ] E2E smoke test
- [ ] World Monitor Finance fork

---

## Blockers

- [ ] First token not yet detected (SENTINEL redeploying)

---

## Free APIs Needed

| Service | Use |
|--------|-----|
| Groq | AI summarization (14.4k/day free) |
| Upstash Redis | Cross-agent cache |
| FRED | Macro data |
| Finnhub | Stock quotes |

## Recent Decisions

| Decision | Reason |
|----------|--------|
| Redis over in-memory | Persistence + pub/sub |
| Railway for deployment | Fastest time to prod |
| SOL thresholds for tokens | USD fields not in WS payload |

---

## Completed

- [x] SENTINEL built
- [x] CIPHER security audit
- [x] UAI transport + schema
- [x] 3-tier memory system
- [x] Episodic memory
